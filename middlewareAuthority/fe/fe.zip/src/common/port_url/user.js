//用户登陆
export const login_url = 'v1/user/login'

//用户注册
export const register_url = 'v1/user/register'

//获取用户信息
export const get_userInfo_url = 'v1/user/get'