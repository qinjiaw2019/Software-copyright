//添加一条记录
export const add_url = 'v1/app/add'

//根据ID删除一条记录
export const del_url = 'v1/app/del'

//修改一条记录
export const edit_url = 'v1/app/edit'

//查询
export const get_url = 'v1/app/get'

//条件查询
export const get_where_url = 'v1/app/get'

//查询记录总数
export const get_tatol_url ='v1/app/get/tatol'

//获取所有应用分类
export const get_app_tepe_url ='v1/app/get/types'