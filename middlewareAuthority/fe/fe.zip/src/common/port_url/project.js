//获得分类的详细信息
export const get_type_projct_info_url = 'v1/project/get/type_projects'