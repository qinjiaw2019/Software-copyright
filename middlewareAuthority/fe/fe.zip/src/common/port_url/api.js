//获取api简单列表
export const get_api_simple_list = 'v1/api/get/list/name'

//根据ID查询详细信息
export const get_api_by_id = 'v1/api/get'