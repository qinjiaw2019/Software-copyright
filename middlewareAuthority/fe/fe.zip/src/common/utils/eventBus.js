/**
 * Created by Administrator on 2017/11/2 0002.
 */
//创建一个vue的实例：
//  获取第三方的vue
//var Vue = require('vue');
import Vue from 'vue';
//导出这个实例
export default new Vue();
