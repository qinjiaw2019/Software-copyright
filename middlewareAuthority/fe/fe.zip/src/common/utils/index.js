import fetch from './fetch'
import {DataTest} from './DataTest'
import validate from './validate'
export {
	fetch,
	DataTest,
	validate
}