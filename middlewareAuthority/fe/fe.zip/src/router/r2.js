//控制台路由配置
import Control from 'pages/control/control'
//import Out from 'pages/out'
//import Form from 'pages/form'
//应用application路由配置
const Form  = r =>require.ensure([], () => r(require('pages/control/form')),'form')
const Index  = r =>require.ensure([], () => r(require('pages/control/application/index')),'index')

//应用列表
const AppList  = r =>require.ensure([], () => r(require('pages/control/application/list')),'applist')
//添加应用
const AppAdd  = r =>require.ensure([], () => r(require('pages/control/application/add')),'appadd')

const Error404  = r =>require.ensure([], () => r(require('pages/404')),'error404')
//首页home
const Home  = r =>require.ensure([], () => r(require('pages/home/index')),'home')


export default [
    {
    	name: 'Control',
        path: '/control',      
        component: Control,
        children: [
       	 {path: 'form',component: Form},
       	 {path: 'index',component: Index},
         {path: 'list',component: AppList},
         {path: 'add',component: AppAdd},

        ]
    },
    {
    	name: 'form',
        path: '/form',      
        component: Form,
    },
    {
        path: '*', 
        component: Error404
    },
    {
    	name: 'home',
        path: '/home',      
        component: Home,
        children: [
            // {path: 'api/list',component: Word},
        ]
    },
]