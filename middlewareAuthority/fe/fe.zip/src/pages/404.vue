<template>
    <div>
    	404错误，页面不存在
    </div>
</template>

<script>
export default{
	
}   
</script>

<style lang="" scoped>
    
</style>