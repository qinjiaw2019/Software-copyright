import {DataTest} from 'common/utils'
/*
 
 * 应用service
 */

/**
 * [list应用表单]
 * @return 
 */

/*
 * 	let data = {
		code:0,
		data:[],	
		msg:'',
	}
 */
export  function list(){
	let data = {
		code:0,
		data:[],	
		msg:'',
	}
	//dat
	return DataTest(data)
}