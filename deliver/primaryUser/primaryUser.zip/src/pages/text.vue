<template>
    <div>
    	<v-header/>
    	text
    </div>
</template>

<script>
export default{
	
}   
</script>

<style lang="" scoped>
    
</style>